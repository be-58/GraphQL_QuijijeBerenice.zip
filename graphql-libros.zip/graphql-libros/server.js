const express = require('express');
const { graphqlHTTP } = require('express-graphql');
const { buildSchema } = require('graphql');

// Define el esquema GraphQL
const schema = buildSchema(`
  type Book {
    id: ID!
    title: String!
    author: String!
    year: Int
  }

  type Query {
    books: [Book]
    book(id: ID!): Book
  }

  type Mutation {
    addBook(title: String!, author: String!, year: Int): Book
    updateBook(id: ID!, title: String, author: String, year: Int): Book
    deleteBook(id: ID!): ID
  }
`);

// Datos de ejemplo
let books = [
  { id: '1', title: 'El Principito', author: 'Antoine de Saint-Exupéry', year: 1943 },
  { id: '2', title: 'Cien años de soledad', author: 'Gabriel García Márquez', year: 1967 }
];

// Resolvers
const root = {
  books: () => books,
  book: ({ id }) => books.find(book => book.id === id),
  addBook: ({ title, author, year }) => {
    const id = String(books.length + 1);
    const newBook = { id, title, author, year };
    books.push(newBook);
    return newBook;
  },
  updateBook: ({ id, title, author, year }) => {
    const bookIndex = books.findIndex(book => book.id === id);
    if (bookIndex === -1) throw new Error('Libro no encontrado');
    const updatedBook = { ...books[bookIndex], title, author, year };
    books[bookIndex] = updatedBook;
    return updatedBook;
  },
  deleteBook: ({ id }) => {
    books = books.filter(book => book.id !== id);
    return id;
  }
};

// Crea el servidor Express
const app = express();

// Configura el endpoint GraphQL
app.use('/graphql', graphqlHTTP({
  schema: schema,
  rootValue: root,
  graphiql: true
}));

// Inicia el servidor
const PORT = 4000;
app.listen(PORT, () => {
  console.log(`Servidor GraphQL corriendo en http://localhost:${PORT}/graphql`);
});